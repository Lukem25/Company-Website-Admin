
<?php
include '../../lib/db.php';

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $db->query("DELETE FROM awards WHERE id = ?", [$id]);
    header('Location: index.php');
}
?>

<html>
<head>
    <title>Delete item</title>
</head>
<body>
    <h1>Are you sure you want to delete this item?</h1>
    <form method="POST">
        <button type="submit">Yes, delete it</button>
    </form>
    <a href="index.php">No, go back</a>
</body>
</html>
    