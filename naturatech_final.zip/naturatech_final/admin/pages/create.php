<?php
include '../../lib/db.php';  // Include the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];

    // Prepare the SQL statement to avoid SQL injection
    $stmt = $db->prepare("INSERT INTO pages (name) VALUES (?)");
    
    // Execute the statement with the provided values
    $stmt->execute([$name]);

    // Redirect to the edit page after creating the new entry
    header('Location: edit.php?id=' . $db->lastInsertId());
    exit;
}
?>

<html>
<head>
    <title>Create new page</title>
</head>
<body>
    <h1>Create new page</h1>
    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" required>
        <button type="submit">Create</button>
    </form>
</body>
</html>