<?php
include '../../lib/db.php';  // Include the database connection

$id = $_GET['id'];  // Get the ID from the URL

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Prepare the SQL statement to delete the specific item
    $stmt = $db->prepare("DELETE FROM pages WHERE id = ?");
    $stmt->execute([$id]);

    // Redirect to the index page after deletion
    header('Location: index.php');
    exit;
}
?>

<html>
<head>
    <title>Delete page</title>
</head>
<body>
    <h1>Are you sure you want to delete this item?</h1>
    <form method="POST">
        <button type="submit">Yes, delete it</button>
    </form>
    <a href="index.php">No, go back</a>
</body>
</html>