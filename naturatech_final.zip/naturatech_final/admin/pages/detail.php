<?php
include '../../lib/db.php';  // Include the database connection

$id = $_GET['id'];  // Get the ID from the URL

// Prepare the SQL statement to fetch the specific item
$stmt = $db->prepare("SELECT * FROM pages WHERE id = ?");
$stmt->execute([$id]);

// Fetch the item from the database
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$item) {
    echo "Page not found.";
    exit;
}
?>

<html>
<head>
    <title>Detail of <?= htmlspecialchars($item['name']) ?></title>
</head>
<body>
    <h1>Detail of <?= htmlspecialchars($item['name']) ?></h1>
    <p>ID: <?= htmlspecialchars($item['id']) ?></p>
    <p>Name: <?= htmlspecialchars($item['name']) ?></p>
    <a href="edit.php?id=<?= $item['id'] ?>">Edit</a>
    <a href="delete.php?id=<?= $item['id'] ?>">Delete</a>
</body>
</html>
