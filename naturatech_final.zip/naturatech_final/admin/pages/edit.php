<?php
include '../../lib/db.php';  // Include the database connection

$id = $_GET['id'];  // Get the ID from the URL

// Prepare the SQL statement to fetch the specific item
$stmt = $db->prepare("SELECT * FROM pages WHERE id = ?");
$stmt->execute([$id]);

// Fetch the item from the database
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the new name from the form
    $name = $_POST['name'];
    
    // Prepare and execute the update statement
    $updateStmt = $db->prepare("UPDATE pages SET name = ? WHERE id = ?");
    $updateStmt->execute([$name, $id]);
    
    // Redirect to the index page after updating
    header('Location: index.php');
    exit;
}
?>

<html>
<head>
    <title>Edit <?= htmlspecialchars($item['name']) ?></title>
</head>
<body>
    <h1>Edit <?= htmlspecialchars($item['name']) ?></h1>
    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($item['name']) ?>" required>
        <button type="submit">Save changes</button>
    </form>
</body>
</html>