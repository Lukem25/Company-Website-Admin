
<?php
include '../../lib/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $db->query("INSERT INTO products (name) VALUES (?)", [$name]);
    header('Location: edit.php?id=' . $db->lastInsertId());
}
?>

<html>
<head>
    <title>Create new products</title>
</head>
<body>
    <h1>Create new products</h1>
    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" required>
        <button type="submit">Create</button>
    </form>
</body>
</html>
    