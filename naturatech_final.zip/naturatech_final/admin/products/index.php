
<?php
include '../../lib/db.php'; // Assuming there's a database connection setup

// Fetch all items from the respective table
$items = $db->query("SELECT * FROM products")->fetchAll();
?>

<html>
<head>
    <title>All products</title>
</head>
<body>
    <h1>List of products</h1>
    <a href="create.php">Create new products</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?= $item['id'] ?></td>
                    <td><?= $item['name'] ?></td>
                    <td>
                        <a href="detail.php?id=<?= $item['id'] ?>">View</a>
                        <a href="edit.php?id=<?= $item['id'] ?>">Edit</a>
                        <a href="delete.php?id=<?= $item['id'] ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
    