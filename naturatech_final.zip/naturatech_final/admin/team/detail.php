
<?php
include '../../lib/db.php';

$id = $_GET['id'];
$item = $db->query("SELECT * FROM team WHERE id = ?", [$id])->fetch();
?>

<html>
<head>
    <title>Detail of <?= $item['name'] ?></title>
</head>
<body>
    <h1>Detail of <?= $item['name'] ?></h1>
    <p>ID: <?= $item['id'] ?></p>
    <p>Name: <?= $item['name'] ?></p>
    <a href="edit.php?id=<?= $item['id'] ?>">Edit</a>
    <a href="delete.php?id=<?= $item['id'] ?>">Delete</a>
</body>
</html>
    