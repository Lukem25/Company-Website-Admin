
<?php
include '../../lib/db.php';

$id = $_GET['id'];
$item = $db->query("SELECT * FROM team WHERE id = ?", [$id])->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $db->query("UPDATE team SET name = ? WHERE id = ?", [$name, $id]);
    header('Location: index.php');
}
?>

<html>
<head>
    <title>Edit <?= $item['name'] ?></title>
</head>
<body>
    <h1>Edit <?= $item['name'] ?></h1>
    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" value="<?= $item['name'] ?>" required>
        <button type="submit">Save changes</button>
    </form>
</body>
</html>
    