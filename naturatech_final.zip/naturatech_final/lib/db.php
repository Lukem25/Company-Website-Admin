
<?php
// db.php: Database connection setup

$host = '127.0.0.1';  // Typically 'localhost' or '127.0.0.1'
$dbname = 'naturatech';  // Name of your database
$user = 'root';  // Default user for XAMPP is 'root'
$pass = '';  // Default password for XAMPP is empty

try {
    // Using PDO for the database connection
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    exit;
}
?>
