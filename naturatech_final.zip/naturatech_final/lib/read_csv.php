
<?php
function readCSV($filePath) {
    $data = array();
    if (($handle = fopen($filePath, 'r')) !== FALSE) {
        while (($row = fgetcsv($handle, 1000, ',')) !== FALSE) {
            $data[] = $row;
        }
        fclose($handle);
    } else {
        return "File not found.";
    }
    return $data;
}
?>
