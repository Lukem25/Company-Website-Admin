
<?php
function readJSON($filePath) {
    if (file_exists($filePath)) {
        $content = file_get_contents($filePath);
        return json_decode($content, true);
    } else {
        return "File not found.";
    }
}
?>
