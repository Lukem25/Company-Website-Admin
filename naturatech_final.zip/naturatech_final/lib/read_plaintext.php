
<?php
function readPlainText($filePath) {
    if (file_exists($filePath)) {
        $content = file_get_contents($filePath);
        return nl2br($content); // Convert new lines to HTML line breaks
    } else {
        return "File not found.";
    }
}
?>
