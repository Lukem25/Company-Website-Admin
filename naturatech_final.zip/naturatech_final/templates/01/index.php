<?php
include '../../lib/read_plaintext.php';
include '../../lib/read_csv.php';
include '../../lib/read_json.php';

// Load data from files
$companyDescription = readPlainText('../../data/company_description.txt');
$teamMembers = [
    ["Dr. Marcus Greene", "Founder & CEO", "Holding a Ph.D. in Environmental Science from Stanford, Dr. Greene has always been a passionate advocate for eco-conscious innovations. His visionary leadership is the bedrock on which NaturaTech stands."],
    ["Aisha Kwon", "CTO", "Aisha, with her background in bio-engineering, is the mastermind behind the cutting-edge technologies at NaturaTech. She believes in harnessing nature's wisdom to address modern challenges."],
    ["Carlos Mendoza", "Chief of Design", "Carlos, an alumnus of Design Academy Eindhoven, combines minimalism with bio-inspired designs, making NaturaTech's products not only functional but also aesthetically appealing."],
    ["Lydia D'souza", "VP of Operations", "Lydia's expertise lies in sustainable supply chains. She ensures that every step in NaturaTech's operations is ethical, green, and efficient."],
    ["Jamal Ahmed", "Head of EcoLearn Hub", "Jamal, a former environmental studies professor from Yale, curates and oversees the rich tapestry of courses offered by EcoLearn, spreading eco-awareness across the globe."]
];
$services = readJSON('../../data/services.json');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>NaturaTech Solutions Inc.</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- CSS Files -->
    <link rel="shortcut icon" href="../../images/favicon.ico" />
    <link href="../../css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="../../css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
    <link href="../../css/style.min.css" rel="stylesheet" type="text/css" />
</head>

<body data-bs-spy="scroll" data-bs-target="#navbar" data-bs-offset="20">
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light navbar-custom fixed-top" id="navbar">
        <div class="container">
            <a class="navbar-brand logo" href="index.php">
                <img src="../../images/logo-dark.png" alt="Logo Dark" class="logo-dark" height="28" />
                <img src="../../images/logo-light.png" alt="Logo Light" class="logo-light" height="28" />
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ms-auto navbar-center">
                    <li class="nav-item"><a href="#home" class="nav-link active">Home</a></li>
                    <li class="nav-item"><a href="#services" class="nav-link">Services</a></li>
                    <li class="nav-item"><a href="#team" class="nav-link">Team</a></li>
                    <li class="nav-item"><a href="#awards" class="nav-link">Awards</a></li>
                    <li class="nav-item"><a href="#contact" class="nav-link">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->

    <!-- Hero Start -->
    <section class="hero-3 bg-center position-relative" style="background-image: url('../../images/hero-3-bg.png');" id="home">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h1 class="font-weight-semibold mb-4 hero-3-title">NaturaTech Solutions Inc.</h1>
                    <p class="mb-5 text-muted subtitle w-75 mx-auto">Established in 2019, NaturaTech Solutions Inc. is an eco-tech enterprise headquartered in Portland, Oregon. Our mission is to produce technology that integrates seamlessly with nature, promoting sustainable living.</p>
                    <h3>Mission Statement</h3>
                    <p class="w-75 mx-auto">"To bridge the chasm between technology and nature, weaving them together to pioneer solutions that nurture the Earth and advance humanity."</p>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero End -->

    <!-- Services Start -->
    <section class="section" id="services">
        <div class="container text-center">
            <h2 class="fw-bold">Our Products & Services</h2>
            <div class="row">
                <?php foreach ($services['services'] as $service): ?>
                    <div class="col-lg-4">
                        <div class="service-box text-center px-4 py-5 position-relative mb-4">
                            <div class="service-box-content p-4">
                                <h4 class="mb-3 font-size-22"><?php echo $service['name']; ?></h4>
                                <p class="text-muted mb-0"><?php echo $service['description']; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <!-- Services End -->

    <!-- Team Start -->
    <section class="section bg-light" id="team">
        <div class="container text-center">
            <h2 class="fw-bold">Our Team Members</h2>
            <div class="row">
                <?php foreach ($teamMembers as $member): ?>
                    <div class="col-lg-12">
                        <div class="team-box mt-4 position-relative overflow-hidden rounded text-left shadow p-4 mb-3">
                            <h5 class="font-size-19 mb-1"><?php echo $member[0]; ?></h5>
                            <p class="text-uppercase font-size-14"><strong><?php echo $member[1]; ?></strong></p>
                            <p class="text-muted"><?php echo $member[2]; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <!-- Team End -->

    <!-- Awards Start -->
    <section class="section" id="awards">
        <div class="container text-center">
            <h2 class="fw-bold">Awards</h2>
            <ul class="list-unstyled text-left mx-auto" style="max-width: 800px;">
                <li>2022: Awarded "Green Innovator of the Year" by Eco Warrior Digest.</li>
                <li>2021: Increased urban green spaces by 150% with GreenRoof� installations.</li>
                <li>2021: Partnered with UNICEF to implement PureStream Filters� in water-scarce areas.</li>
                <li>2020: TerraCharge� pathways adopted by 20 major city parks globally.</li>
            </ul>
        </div>
    </section>
    <!-- Awards End -->

    <!-- Footer Start -->
    <footer class="footer" style="background-image: url('../../images/footer-bg.png');">
        <div class="container text-center">
            <p>� <?php echo date("Y"); ?> NaturaTech Solutions Inc. All rights reserved.</p>
        </div>
    </footer>
    <!-- Footer End -->

    <!-- JavaScript Files -->
    <script src="../../js/bootstrap.bundle.min.js"></script>
    <script src="../../js/smooth-scroll.polyfills.min.js"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="../../js/app.js"></script>
</body>
</html>